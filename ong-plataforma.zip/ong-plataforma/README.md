# Mãos Unidas — Plataforma para ONGs (Entrega II — CSS3)
## Estrutura
- `index.html` — página principal
- `css/` — CSS modular (variables, base, grid, layout, navigation, components, forms, feedback, responsive)
- `js/main.js` — interações (menu, modal, toast, validação)
- `img/` — imagens (adicione projeto1.jpg, projeto2.jpg, projeto3.jpg)
## Integrantes
- (nomes do grupo)
